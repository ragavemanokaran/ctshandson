﻿namespace CodeAnalysis1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
        }
    }
}
